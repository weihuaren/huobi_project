
class OutputKey:
    KeyData = "data"
    KeyTick = "tick"
    KeyChannelCh = "ch"
    KeyChannelRep = "rep"





